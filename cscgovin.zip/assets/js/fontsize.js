var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

	 $(document).ready(function() {
		 
		$('#incfont').click(function(){	   
        curSize= parseInt($('#content').css('font-size')) + 2;
		if(curSize<=20)
        $('#content').css('font-size', curSize);
        });
		
     $('#decfont1').click(function(){	   
        curSize= parseInt($('#content').css('font-size'));
		//alert(curSize);
		//if(curSize<=14)
        $('#content').css('font-size', 14);
        }); 
		
		$('#decfont').click(function(){	   
        curSize= parseInt($('#content').css('font-size')) - 2;
		if(curSize>=8)
        $('#content').css('font-size', curSize);
        }); 
		
	});


}

/*
playback timings (ms):
  captures_list: 3682.407
  exclusion.robots.policy: 0.207
  CDXLines.iter: 20.309 (3)
  esindex: 0.008
  LoadShardBlock: 3189.521 (3)
  PetaboxLoader3.resolve: 1373.077 (3)
  RedisCDXSource: 468.619
  PetaboxLoader3.datanode: 2993.211 (5)
  load_resource: 2257.445
  exclusion.robots: 0.22
*/