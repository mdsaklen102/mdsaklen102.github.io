var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");



}

/*
playback timings (ms):
  PetaboxLoader3.resolve: 1271.139 (3)
  CDXLines.iter: 24.765 (3)
  exclusion.robots: 0.197
  LoadShardBlock: 1682.197 (3)
  exclusion.robots.policy: 0.182
  RedisCDXSource: 11.267
  captures_list: 1731.843
  PetaboxLoader3.datanode: 555.604 (4)
  load_resource: 407.78
  esindex: 0.016
*/